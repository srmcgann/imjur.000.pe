<?php 
  $db_user  = 'if0_36324953';
  $db_pass  = 'p7bQZRnvTdjuCtK';
  $db_host  = 'sql212.infinityfree.com';
  $db       = "if0_36324953_imjur";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
?>